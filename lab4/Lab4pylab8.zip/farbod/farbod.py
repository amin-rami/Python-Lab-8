def squere(inp):
    return inp**2